package com.vforum;

import org.hibernate.SessionFactory;

import com.vforum.model.Admin;
import com.vforum.service.ForumService;

public class MainApp {

	private static SessionFactory sessionFactory;

	public static void main(String[] args) {
		ForumService service = new ForumService();
		service.registerAdmin(new Admin(999,"kaushik", "admin"));
		// Configuration configuration = new Configuration();
		// configuration.configure("hibernate.cfg.xml");
		// //
		// System.out.println(configuration.getProperty("hibernate.connection.url"));
		// sessionFactory = configuration.buildSessionFactory();
		// Session session = sessionFactory.openSession();
		// Transaction transaction = session.beginTransaction();
		// // Employee employee = new Employee(501, "Vaibhav kaushik", "engg",
		// // "engg", "xyz", "12345");
		// // session.saveOrUpdate(employee);
		//
		//// Employee employee = session.get(Employee.class, 501);
		//// List<Post> posts = employee.getPosts();
		//// List<Answer> answers = employee.getAnswers();
		//// session.delete(posts.get(1));
		//// posts.remove(1);
		//// session.flush();
		//
		// // for (int i = 0; i < 3; i++) {
		// // Post p = new Post("Post No == " + i, employee1);
		// // session.saveOrUpdate(p);
		// // for (int j = 0; j < 2; j++) {
		// // Answer a = new Answer("Answer no == " + j, employee1, p);
		// // session.saveOrUpdate(a);
		// // }
		// // }
		// // List<Post> postss = employee.getPosts();
		// // for (Post p : postss) {
		// //// for (int i = 0; i < 2; i++) {
		// //// Answer a = new Answer("AnswerAdded?? - " + i, employee, p);
		// //// session.saveOrUpdate(Answer.class, a);
		// //// }
		// // }
		// session.flush();
		// transaction.commit();
		// session.close();
	}
}
