package com.vforum.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.vforum.model.Admin;
import com.vforum.service.ForumService;
import com.vforum.util.Utils;

@WebServlet("/AdminLoginController")
public class AdminLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AdminLoginController() {
		super();

	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Logger logger = Logger.getLogger("AdminLoginController");
		response.setContentType("text/html");
		ForumService service = new ForumService();
		int adminId = Utils.parseStringToInt(request.getParameter("admin_id").trim());
		String password = request.getParameter("passwrd");
		Admin currentAdmin = null;
		try {
			int flag = service.doAdminLoginCheck(adminId, password);
			currentAdmin = Utils.getAdminFromId(adminId);
			logger.info("calling dao with username and password");
			if (flag == 0){
				logger.info("Not Successfully login");
				logger.info("Login Not Sucesfull <<<<<<<<<< By Admin" + currentAdmin.toString() + "Flag " + flag);
				request.setAttribute("message", "username/password is wrong");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/login.jsp");
				dispatcher.forward(request, response);
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("emp_id", currentAdmin.getAdminId());
				session.setAttribute("user_name", currentAdmin.getAdminUname());
				session.setAttribute("adminCheck", true);
				request.setAttribute("message", "Login Sucess ");
				logger.info("Login Sucesfull <<<<<<<<<< By Admin" + currentAdmin.toString());
				RequestDispatcher dispatcher = request.getRequestDispatcher("/HomeController");
				dispatcher.forward(request, response);
			}

		} catch (Exception e) {
			try {
				request.setAttribute("message", "username/pasword is wrong");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/jsp/login.jsp");
				dispatcher.forward(request, response);
				logger.error("internal error while login", e);
			} catch (Exception e1) {
				logger.error("error", e1);
			}

		}

	}

}
