package com.vforum.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.service.ForumService;
import com.vforum.util.Utils;

@WebServlet("/DeleteAnswerController")
public class DeleteAnswerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteAnswerController() {
		super();
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	/**
	 * @throws IOException
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("DeleteAnswerController");
		response.setContentType("text/html");
		int postId = Utils.parseStringToInt(request.getParameter("deleteAnswer"));
		ForumService service = new ForumService();
		service.deleteAnswer(postId);
		request.setAttribute("message", "Answer Deleted");

		RequestDispatcher dispatcher = request.getRequestDispatcher("/HomeController");
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
}
