package com.vforum.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.vforum.model.Post;
import com.vforum.service.ForumService;
import com.vforum.util.Utils;

@WebServlet("/UpdatePostController")
public class UpdatePostController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UpdatePostController() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("UpdatePostController");
		response.setContentType("text/html");
		String postdesc = request.getParameter("postdesc");
		int postId = Utils.parseStringToInt(request.getParameter("currentpostId"));
		Post post = new Post(postdesc);
		logger.info("This is in UpdatePostController <<<<<<<<<<<<<<<" + post.toString() + " || " + postId);
		ForumService service = new ForumService();
		service.editPost(post, postId);
		logger.info(post.toString());
		request.setAttribute("message1", "Post Edited");

		RequestDispatcher dispatcher = request.getRequestDispatcher("/HomeController");
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			logger.error(e);
		}
	}

}
