package com.vforum.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.vforum.model.Answer;
import com.vforum.service.ForumService;

@WebServlet("/ViewAnsController")
public class ViewAnsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ViewAnsController() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Logger logger = Logger.getLogger("SearchController");
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		String s = "empId";
		logger.info("Session Emp Recieved Obj<<<<<<<<< " + session.getAttribute(s));
		int answerPostQuery = (int) session.getAttribute(s);
		logger.info("Session Emp Recieved <<<<<<<<< " + session.getAttribute(s));
		if (answerPostQuery == 0) {
			logger.error("Answer Post query is empty");
		}
		ForumService service = new ForumService();
		List<Answer> list = service.fetchAnswers(answerPostQuery);
		if (list.isEmpty()) {
			try {
				request.setAttribute("answers", list);
				request.getRequestDispatcher("/jsp/viewAnswer.jsp").forward(request, response);
			} catch (Exception e) {
				logger.error(e);
			}
		} else {
			for (Answer a : list) {
				logger.info("Answer A ||| " + a.toString());
			}
			request.setAttribute("answers", list);
			try {
				request.getRequestDispatcher("/jsp/viewAnswer.jsp").forward(request, response);
			} catch (Exception e) {
				logger.error(e);
			}
		}

	}

}
