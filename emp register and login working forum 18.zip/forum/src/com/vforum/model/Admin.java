package com.vforum.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admintab")
public class Admin {
	@Id
	private int adminId;
	private String adminUname;
	private String adminPassword;

	public Admin(int adminId, String adminUname, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminUname = adminUname;
		this.adminPassword = adminPassword;
	}

	public Admin(int adminId, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminPassword = adminPassword;
	}

	public Admin(String adminUname, String adminPassword) {
		super();
		this.adminUname = adminUname;
		this.adminPassword = adminPassword;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminUname() {
		return adminUname;
	}

	public void setAdminUname(String adminUname) {
		this.adminUname = adminUname;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return "Admin [admin_id=" + adminId + ", admin_uname=" + adminUname + "]";
	}

}
