package com.vforum.service;

import java.util.List;

import com.vforum.dao.ForumDao;
import com.vforum.model.Admin;
import com.vforum.model.Answer;
import com.vforum.model.Employee;
import com.vforum.model.Post;

public class ForumService implements IForum {
	private static ForumDao dao = new ForumDao();
	
	@Override
	public int registerAdmin(Admin admin) {
		
		return dao.registerAdmin(admin);
	}
	
	@Override
	public int registerEmployee(Employee employee) {
		
		return dao.registerEmployee(employee);
	}
	
	@Override
	public int createPost(Post post, int empId) {
		
		return dao.createPost(post, empId);
	}
	
	@Override
	public int editPost(Post post, int postId) {
		
		return dao.editPost(post, postId);
	}
	
	@Override
	public int addAnswer(Answer answer, int postId, int empId) {
		
		return dao.addAnswer(answer, postId, empId);
	}
	
	@Override
	public int editAnswer(Answer answer, int answerId) {
		
		return dao.editAnswer(answer, answerId);
	}
	
	@Override
	public List<Answer> fetchAnswers(int empId) {
		
		return dao.fetchAnswers(empId);
	}
	
	@Override
	public List<Post> fetchPosts(int empId) {
		
		return dao.fetchPosts(empId);
	}
	
	@Override
	public List<Answer> fetchPostAnswers(int postId) {
		
		return dao.fetchPostAnswers(postId);
	}
	
	@Override
	public List<Post> searchPosts(String searchQuery) {
		
		return dao.searchPosts(searchQuery);
	}
	
	@Override
	public int doEmpLoginCheck(int empId, String password) {
		return dao.doEmpLoginCheck(empId, password);
	}
	
	@Override
	public int doAdminLoginCheck(int adminId, String password) {
		
		return dao.doAdminLoginCheck(adminId, password);
	}
	
	@Override
	public List<Answer> searchAnswer(String searchQuery) {
		
		return dao.searchAnswer(searchQuery);
	}
	
	@Override
	public List<Post> fetchPostByDate() {
		
		return dao.fetchPostByDate();
	}
	
	@Override
	public int deletePost(int postId) {
		
		return dao.deletePost(postId);
	}
	
	@Override
	public int deleteAnswer(int answerId) {
		
		return dao.deleteAnswer(answerId);
	}
}
