package com.vforum.service;

import java.util.List;

import com.vforum.model.Admin;
import com.vforum.model.Answer;
import com.vforum.model.Employee;
import com.vforum.model.Post;

interface IForum {
	
	int doEmpLoginCheck(int empId, String password);
	
	int doAdminLoginCheck(int adminId, String password);
	
	int registerAdmin(Admin admin);
	
	int registerEmployee(Employee employee);
	
	int createPost(Post post, int empId);
	
	int editPost(Post post, int postId);
	
	int addAnswer(Answer answer, int postId, int empId);
	
	int editAnswer(Answer answer, int answerId);
	
	List<Post> fetchPostByDate();
	
	int deletePost(int postId);
	
	int deleteAnswer(int answerId);
	
	List<Answer> fetchAnswers(int empId);
	
	List<Post> fetchPosts(int empId);
	
	List<Answer> fetchPostAnswers(int postId);
	
	List<Post> searchPosts(String searchQuery);
	
	List<Answer> searchAnswer(String searchQuery);
	
}
